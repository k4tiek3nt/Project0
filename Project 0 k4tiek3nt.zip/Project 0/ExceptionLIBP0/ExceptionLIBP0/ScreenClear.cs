﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ExceptionLIBP0
{
    public class ScreenClear
    {
        public void ReturnToMenu()
        {
            Thread.Sleep(2000);
            Console.WriteLine("Press Enter to Return to Main Menu.");
            Console.ReadLine();
            Console.Clear();
        }
        public void DefaultClear()
        {
            Thread.Sleep(2000);
            Console.Clear();
        }
    }
}
