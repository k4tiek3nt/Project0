﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLIBP0
{
    public class Savings : Accounts
    {
        //public Savings(int p_accNo, string p_accName, int p_accBalance, string p_accIsActive, Type p_accType, int p_accBranch) : base(p_accNo, p_accName, p_accBalance, p_accIsActive, p_accType, p_accBranch)
        //{
        //    //Console.WriteLine("Account Number: " + p_accNo);
        //    //Console.WriteLine("Account Name: " + p_accName);
        //    //Console.WriteLine("Account Balance: " + p_accBalance);
        //    //Console.WriteLine("Account Type: " + p_accType);
        //    //Console.WriteLine("Account is Active: " + p_accIsActive);
        //    //Console.WriteLine("Account Branch: " + p_accBranch);
        //}
        public override int Withdrawl(int p_withdrawlAmt, int p_balance)
        {
            if (p_withdrawlAmt > 20000)
            {
                throw new Exception("Savings account is allowed a maximum widrawal of $20,000.00");
            }
            return base.Withdrawl(p_withdrawlAmt, p_balance);
        }

        public override int Deposit(int p_depositAmt, int p_balance)
        { 
            if (p_depositAmt > 50000)
            {
                throw new Exception("Your maximum deposit is $50,000.00 in a day");
            }
            return base.Deposit(p_depositAmt, p_balance);
        }

    }
}

