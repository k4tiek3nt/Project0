﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ExceptionLIBP0
{
      public class Accounts
    {
        public int accNo { get; set; }
        public string accName { get; set; }
        public int accBalance { get; set; }
        public string accIsActive { get; set; }
        public string accType { get; set; }
        public int accBranch { get; set; }


        //public Accounts(int p_accNo, string p_accName, int p_accBalance, string p_accIsActive, Type p_accType, int p_accBranch)
        //{
        //    accNo = p_accNo;
        //    accName = p_accName;
        //    accBalance = p_accBalance;

        //    if (accName.Length < 3)
        //    {
        //        throw new Exception("Please provide a name longer than 3 Characters.");
        //    }
        //    if (accBalance < 100)
        //    {
        //        throw new Exception("Sorry cannot open your account, as initial funding needs to be $100.00"); <-- need this code in app!
        //    }
        //    //this.accIsActive = true;
        //    accType = p_accType.ToString();
        //    accBranch = p_accBranch;
        //    this.accIsActive = p_accIsActive == true;

        //}

        public virtual int Withdrawl(int p_withdrawlAmt, int p_balance)
        {
            if (p_withdrawlAmt < 0)
            {
                throw new Exception("Sorry cannot allow withdrawing negative amount.");
            }
            if (p_withdrawlAmt > p_balance)
            {
                throw new Exception("Insufficent Balance.");
            }
            p_balance = p_balance - p_withdrawlAmt;
            return p_balance;
        }

        public virtual int Deposit(int p_depositAmt, int p_balance)
        {
            if (p_depositAmt < 0)
            {
                throw new Exception("Sorry cannot accept negative amount.");
            }

            p_balance = p_balance + p_depositAmt;
            return p_balance;
        }

        //SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=citibankDB;integrated security=true");

        //public bool CheckAccountExist(int p_accNo)
        //{
        //    SqlCommand cmdCheck = new SqlCommand("select count(*) from accountInfo where accNo = @aNo", con);
        //    cmdCheck.Parameters.AddWithValue("@aNo", p_accNo);

        //    con.Open();
        //    int count = (int)cmdCheck.ExecuteScalar();
        //    con.Close();
        //    if (count == 1)
        //    {
        //        return true;
        //    }
        //    return false;
        //}

        //public string AddAccount(Accounts p_accObj)
        //{

        //    SqlCommand cmdNewAccount = new SqlCommand("insert into accountInfo (accNo, accName, accType, accBalance, accBranch) values (@aNo,@aName,@aType,@aBal,@aBNo)", con);
        //    cmdNewAccount.Parameters.AddWithValue("@aNo", p_accObj.accNo);
        //    cmdNewAccount.Parameters.AddWithValue("@aName", p_accObj.accName);
        //    cmdNewAccount.Parameters.AddWithValue("@aType", p_accObj.accType);
        //    cmdNewAccount.Parameters.AddWithValue("@aBal", p_accObj.accBalance);
        //    cmdNewAccount.Parameters.AddWithValue("@aBNo", p_accObj.accBranch);
        //    con.Open();
        //    int recordsAffected = cmdNewAccount.ExecuteNonQuery(); //this method returns number of records affected in datbase
        //    con.Close();
        //    return "Bank Account Added Successfully";
        //}

    }
}
