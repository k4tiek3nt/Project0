﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace ExceptionLIBP0
{
    public class Branch
    {
        public int brNo { get; set; }
        public string brName { get; set; }
        public string brCity { get; set; }
        public string brEmail { get; set; }
        public int brContact { get; set; }

        //branchInfo - table name


        SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=citibankDB;integrated security=true");
        public bool CheckBrachExist(int p_brNo)
        {
            SqlCommand cmdCheckBranch = new SqlCommand("select count(*) from branchInfo where brNo = @bNo", con);
            cmdCheckBranch.Parameters.AddWithValue("@bNo", p_brNo);

            con.Open();
            int count = (int)cmdCheckBranch.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }

    }
}
