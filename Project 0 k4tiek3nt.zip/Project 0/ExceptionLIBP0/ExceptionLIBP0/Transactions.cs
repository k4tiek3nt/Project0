﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ExceptionLIBP0

{
    public class Transactions
    {
        public int transId { get; set; }
        public DateTime transDate { get; set; }
        public string transType { get; set; }
        public int fromAcc { get; set; }
        public string fromAccType { get; set; }
        public int toAcc { get; set; }
        public string toAccType { get; set; }
        public int transAmt { get; set; }
        public string transferredBy { get; set; }
        //transactionInfo - table name

        SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=citibankDB;integrated security=true");

        public string Transfer(string p_transType, int p_fromAcc, string p_fromAccType, int p_toAcc, string p_toAccType, int p_amount, string p_userRole)
        {
            SqlCommand cmdFrom = new SqlCommand("update AccountsInfo set accBalance = accBalance - @amount where accNo = @fromAccount and accType = @fromAccType", con);
            cmdFrom.Parameters.AddWithValue("@amount", p_amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdFrom.Parameters.AddWithValue("@fromAccType", p_fromAccType);

            SqlCommand cmdTo = new SqlCommand("update AccountsInfo set accBalance = accBalance + @amount where accNo = @toAccount and accType = @toAccType", con);
            cmdTo.Parameters.AddWithValue("@amount", p_amount);
            cmdTo.Parameters.AddWithValue("@toAccount", p_toAcc);
            cmdTo.Parameters.AddWithValue("@toAccType", p_toAccType);


            SqlCommand cmdTransaction = new SqlCommand("insert into TransactionInfo values (GETDATE(),@transType,@fromAccount,@fromAccType,@toAccount,@toAccType,@amount,@userRole)", con);
            cmdTransaction.Parameters.AddWithValue("@transType", p_transType);
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdTransaction.Parameters.AddWithValue("@fromAccType", p_fromAccType);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_toAcc);
            cmdTransaction.Parameters.AddWithValue("@toAccType", p_toAccType);
            cmdTransaction.Parameters.AddWithValue("@amount", p_amount);
            cmdTransaction.Parameters.AddWithValue("@userRole", p_userRole);

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Transfer Complete";
        }

        public string Deposit(string p_transType, int p_toAcc, string p_toAccType, int p_amount, string p_userRole)
        {
            SqlCommand cmdTo = new SqlCommand("update AccountsInfo set accBalance = accBalance + @amount where accNo = @toAccount and accType = @toAccType", con);
            cmdTo.Parameters.AddWithValue("@amount", p_amount);
            cmdTo.Parameters.AddWithValue("@toAccount", p_toAcc);
            cmdTo.Parameters.AddWithValue("@toAccType", p_toAccType);


            SqlCommand cmdTransaction = new SqlCommand("insert into TransactionInfo (transDate,transType, toAcc, toAccType, transAmt,transferredBy) values (GETDATE(),@transType,@toAccount,@toAccType,@amount,@userRole)", con);
            cmdTransaction.Parameters.AddWithValue("@transType", p_transType);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_toAcc);
            cmdTransaction.Parameters.AddWithValue("@toAccType", p_toAccType);
            cmdTransaction.Parameters.AddWithValue("@amount", p_amount);
            cmdTransaction.Parameters.AddWithValue("@userRole", p_userRole);

            con.Open();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Deposit Complete";
        }

        public string Withdrawl(string p_transType, int p_fromAcc, string p_fromAccType, int p_amount, string p_userRole)
        {
            SqlCommand cmdFrom = new SqlCommand("update AccountsInfo set accBalance = accBalance - @amount where accNo = @fromAccount and AccType = @fromAccType", con);
            cmdFrom.Parameters.AddWithValue("@amount", p_amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdFrom.Parameters.AddWithValue("@fromAccType", p_fromAccType);

            SqlCommand cmdTransaction = new SqlCommand("insert into TransactionInfo (transDate,transType, fromAcc, fromAccType, transAmt,transferredBy) values (GETDATE(),@transType,@fromAccount,@fromAccType,@amount,@userRole)", con);
            cmdTransaction.Parameters.AddWithValue("@transType", p_transType);
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdTransaction.Parameters.AddWithValue("@fromAccType", p_fromAccType);
            cmdTransaction.Parameters.AddWithValue("@amount", p_amount);
            cmdTransaction.Parameters.AddWithValue("@userRole", p_userRole);

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Withdrawl Complete";
        }

        public List<Transactions> GetLast10Trans(string p_accName)
        {

            SqlCommand cmdGetLast10 = new SqlCommand("select top 10 transID, transDate, transType, fromAcc, fromAccType, toAcc, toAccType, transAmt, transferredBy from transactionInfo t full join accountsInfo a on t.fromAcc = a.accNo or t.toAcc = a.accNo where a.accName = @accName order by transID desc;", con);
            cmdGetLast10.Parameters.AddWithValue("@accName", p_accName);

            con.Open();
            SqlDataReader readRecord = cmdGetLast10.ExecuteReader(); //this is point to output of query (not table)

            //then u will ask it to point to next record
            List<Transactions> trList = new List<Transactions>();
            while (readRecord.Read())
            {
                try
                {
                    trList.Add(new Transactions()
                    {
                        transId = (int)readRecord[0],
                        transDate = (DateTime)readRecord[1],
                        transType = readRecord[2].ToString(),
                        fromAcc = (int)(!Convert.IsDBNull(readRecord[3]) ? (int?)readRecord[3] : 000), //(int)readRecord[3],
                        fromAccType = readRecord[4].ToString(),
                        toAcc = (int)(!Convert.IsDBNull(readRecord[5]) ? (int?)readRecord[5] : 000), //(int)readRecord[5],
                        toAccType = readRecord[6].ToString(),
                        transAmt = (int)readRecord[7],
                        transferredBy = readRecord[8].ToString(),
                    });
                }
                catch (Exception es)
                {
                    Console.WriteLine(es.Message);
                }
            }
            readRecord.Close();
                con.Close();
                return trList;
        }

        public List<Transactions> GetLast10TransbyAcc(int p_accNo)
        {

            SqlCommand cmdGetLast10 = new SqlCommand("select top 10 transID, transDate, t.transType, t.fromAcc, t.fromAccType, t.toAcc, t.toAccType, t.transAmt, t.transferredBy from transactionInfo t full join accountsInfo a on t.fromAcc = a.accNo or t.toAcc = a.accNo where a.accNo = @accNo order by transID desc;", con);
            cmdGetLast10.Parameters.AddWithValue("@accNo", p_accNo);

            con.Open();
            SqlDataReader readRecord = cmdGetLast10.ExecuteReader(); //this is point to output of query (not table)

            //then u will ask it to point to next record
            List<Transactions> trList = new List<Transactions>();
            while (readRecord.Read())
            {
                try
                {
                    trList.Add(new Transactions()
                    {
                        transId = (int)readRecord[0],
                        transDate = (DateTime)readRecord[1],
                        transType = readRecord[2].ToString(),
                        fromAcc = (int)(!Convert.IsDBNull(readRecord[3]) ? (int?)readRecord[3] : 0), //(int)readRecord[3],
                        fromAccType = readRecord[4].ToString(),
                        toAcc = (int)(!Convert.IsDBNull(readRecord[5]) ? (int?)readRecord[5] : 0), //(int)readRecord[5],
                        toAccType = readRecord[6].ToString(),
                        transAmt = (int)readRecord[7],
                        transferredBy = readRecord[8].ToString(),
                    });
                }
                catch (Exception es)
                {
                    Console.WriteLine(es.Message);
                }
            }
            readRecord.Close();
            con.Close();
            return trList;
        }
    }
    
}


