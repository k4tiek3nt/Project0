﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace ExceptionLIBP0
{
    public class BankAccount : Accounts

    {

        //public BankAccount(int p_accNo, string p_accName, int p_accBalance, string p_accIsActive, Type p_accType, int p_accBranch) : base(p_accNo, p_accName, p_accBalance, p_accIsActive, p_accType, p_accBranch)
        //{
        //    //Console.WriteLine("Account Number: " + p_accNo);
        //    //Console.WriteLine("Account Name: " + p_accName);
        //    //Console.WriteLine("Account Balance: " + p_accBalance);
        //    //Console.WriteLine("Account Type: " + p_accType);
        //    //Console.WriteLine("Account is Active: " + p_accIsActive);
        //    //Console.WriteLine("Account Branch: " + p_accBranch);
        //}

        SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=citibankDB;integrated security=true");

        public bool CheckAccountExist(int p_accNo)
        {
            SqlCommand cmdCheck = new SqlCommand("select count(*) from accountsInfo where accNo = @aNo", con);
            cmdCheck.Parameters.AddWithValue("@aNo", p_accNo);

            con.Open();
            int count = (int)cmdCheck.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        public bool CheckAccountActive(int p_accNo)
        {
            SqlCommand cmdCheckActive = new SqlCommand("select count(*) from accountsInfo where accIsActive = @accActive and accNo = @aNo", con);
            cmdCheckActive.Parameters.AddWithValue("@accActive", "Active");
            cmdCheckActive.Parameters.AddWithValue("@aNo", p_accNo);

            con.Open();
            int count = (int)cmdCheckActive.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        public string GetAccountType(int p_accNo)
        {
            SqlCommand cmdGetAccType = new SqlCommand("select accType from accountsInfo where accNo=@aNo", con);
            cmdGetAccType.Parameters.AddWithValue("@aNo", p_accNo);

            con.Open();
            SqlDataReader readRecord = cmdGetAccType.ExecuteReader(); //store the output in read variable
            BankAccount acc = new BankAccount();
            if (readRecord.Read()) //start reading please
            {
                acc.accType = readRecord[0].ToString();

            }
            else
            {
                throw new Exception("Record Not Found");
            }
            readRecord.Close();
            con.Close();

            return acc.accType;

        }

        public List<BankAccount> GetLastAccount()
        {

            SqlCommand cmdLastAccount = new SqlCommand("select top 1 * from accountsInfo order by accNo desc", con);
            con.Open();
            SqlDataReader readLastAcc = cmdLastAccount.ExecuteReader(); //this is point to output of query (not table)

            List<BankAccount> lastAccList = new List<BankAccount>();
            while (readLastAcc.Read())
            {
                lastAccList.Add(new BankAccount()
                {
                    accNo = (int)readLastAcc[0],
                    accName = readLastAcc[1].ToString(),
                    accType = readLastAcc[2].ToString(),
                    accBalance = (int)readLastAcc[3],
                    accIsActive = readLastAcc[4].ToString(),
                    accBranch = (int)readLastAcc[5]
                });
            }
            readLastAcc.Close();
            con.Close();
            return lastAccList;
        }


        public string AddAccount(string p_aName, string p_aType, int p_aBal, int p_aBNo)
        {
            SqlCommand cmdNewAccount = new SqlCommand("insert into accountsInfo (accName, accType, accBalance, accBranch) values (@aName,@aType,@aBal,@aBNo)", con);
            //cmdNewAccount.Parameters.AddWithValue("@aNo", ); will return after created
            cmdNewAccount.Parameters.AddWithValue("@aName", p_aName);
            cmdNewAccount.Parameters.AddWithValue("@aType", p_aType);
            cmdNewAccount.Parameters.AddWithValue("@aBal", p_aBal);
            cmdNewAccount.Parameters.AddWithValue("@aBNo", p_aBNo);
            con.Open();
            int recordsAffected = cmdNewAccount.ExecuteNonQuery(); //this method returns number of records affected in datbase
            con.Close();
            if (recordsAffected == 1)
            {
                return "Bank Account Added Successfully";

            }
            else
            {
                return "Bank Account Not Added";
            }
        }

        public List<BankAccount> GetAllBankAccounts()
        {
            //by default ordered by Account Number, could change to "order by accName" or other column 
            //(inside quotes after accountsInfo) i.e. - ("select * from accountsInfo order by accName", con);
            SqlCommand cmdAllBankAccounts = new SqlCommand("select * from accountsInfo", con);
            con.Open();
            SqlDataReader readAcc = cmdAllBankAccounts.ExecuteReader(); //this is point to output of query (not table)

            //then u will ask it to point to next record
            List<BankAccount> accList = new List<BankAccount>();
            while (readAcc.Read())
            {
                accList.Add(new BankAccount()
                {
                    accNo = (int)readAcc[0],
                    accName = readAcc[1].ToString(),
                    accType = readAcc[2].ToString(),
                    accBalance = (int)readAcc[3],
                    accIsActive = readAcc[4].ToString(),
                    accBranch = (int)readAcc[5]
                });
            }
            readAcc.Close();
            con.Close();
            return accList;
        }

        public List<BankAccount> GetAccountDetails(int p_accNo_forSearchById)
        {
            SqlCommand cmdGetBankAccount = new SqlCommand("select * from accountsInfo where accNo = @accNo", con);
            cmdGetBankAccount.Parameters.AddWithValue("@accNo", p_accNo_forSearchById);
            con.Open();
            SqlDataReader readAcc = cmdGetBankAccount.ExecuteReader(); //this is point to output of query (not table)

            //then u will ask it to point to next record
            List<BankAccount> accList = new List<BankAccount>();
            while (readAcc.Read())
            {
                accList.Add(new BankAccount()
                {
                    accNo = (int)readAcc[0],
                    accName = readAcc[1].ToString(),
                    accType = readAcc[2].ToString(),
                    accBalance = (int)readAcc[3],
                    accIsActive = readAcc[4].ToString(),
                    accBranch = (int)readAcc[5]
                });
            }
            readAcc.Close();
            con.Close();
            return accList;
        }

        public int GetAccountBalance(int p_accNo)
        {
            SqlCommand cmdGetBalance = new SqlCommand("select accBalance from accountsInfo where accNo=@aNo", con);
            cmdGetBalance.Parameters.AddWithValue("@aNo", p_accNo);

            con.Open();
            SqlDataReader readRecord = cmdGetBalance.ExecuteReader(); //store the output in read variable
            BankAccount acc = new BankAccount();
            if (readRecord.Read()) //start reading please
            {
                acc.accBalance = (int)readRecord[0];

            }
            else
            {
                throw new Exception("Record Not Found");
            }
            readRecord.Close();
            con.Close();

            return acc.accBalance;
        }


        public string DeactivateAccount(int p_accNo)
        {
            SqlCommand cmdDeactivateAcc = new SqlCommand("update accountsInfo set accIsActive=@Active where accNo=@aNo", con);

            cmdDeactivateAcc.Parameters.AddWithValue("@aNo", p_accNo);
            cmdDeactivateAcc.Parameters.AddWithValue("@Active", "Disabled");


            con.Open();
            int updateResult2 = cmdDeactivateAcc.ExecuteNonQuery();
            con.Close();

            if (updateResult2 == 1)
            {
                return "Account Disabled Successfully";
            }
            return "Account Not Found";

        }
        public string ReactivateAccount(int p_accNo)
        {
            SqlCommand cmdReactivateAcc = new SqlCommand("update accountsInfo set accIsActive=@Active where accNo=@aNo", con);

            cmdReactivateAcc.Parameters.AddWithValue("@aNo", p_accNo);
            cmdReactivateAcc.Parameters.AddWithValue("@Active", "Active");


            con.Open();
            int updateResult2 = cmdReactivateAcc.ExecuteNonQuery();
            con.Close();

            if (updateResult2 == 1)
            {
                return "Account ReActivated Successfully";
            }
            return "Account Not Found";

        }

        public override int Withdrawl(int p_withdrawlAmt, int p_balance)
        {
            return base.Withdrawl(p_withdrawlAmt, p_balance);
        }

        public bool GetAccountsByUser(string p_accName)
        {
            SqlCommand cmdGetAccounts = new SqlCommand("SELECT count(accName) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = @uName group by accName;", con);
            cmdGetAccounts.Parameters.AddWithValue("@uName", p_accName);


            con.Open();
            int count = (int)cmdGetAccounts.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;

        }

        public int GetBalanceByUser(string p_accName)
        {

            SqlCommand cmdGetBalanceByUser = new SqlCommand("select accBalance from accountsInfo where accName = @uName", con);
            cmdGetBalanceByUser.Parameters.AddWithValue("@uName", p_accName);

            con.Open();
            SqlDataReader readRecord = cmdGetBalanceByUser.ExecuteReader(); //store the output in read variable
            BankAccount acc = new BankAccount();
            if (readRecord.Read()) //start reading please
            {
                acc.accBalance = (int)readRecord[0];

            }
            else
            {
                throw new Exception("Record Not Found");
            }
            readRecord.Close();
            con.Close();

            return acc.accBalance;

        }

        public List<BankAccount> GetAllAccountsByUser(string p_accName)
        {
            SqlCommand cmdGetBankAccounts = new SqlCommand("select accNo,accType,accBalance from accountsInfo where accName = @uName and accIsActive = 'Active'", con);
            cmdGetBankAccounts.Parameters.AddWithValue("@uName", p_accName);
            con.Open();
            SqlDataReader readAcc = cmdGetBankAccounts.ExecuteReader(); //this is point to output of query (not table)

            //then u will ask it to point to next record
            List<BankAccount> accList = new List<BankAccount>();
            while (readAcc.Read())
            {
                accList.Add(new BankAccount()
                {
                    accNo = (int)readAcc[0],
                    accType = readAcc[1].ToString(),
                    accBalance = (int)readAcc[2],

                });
            }
            readAcc.Close();
            con.Close();
            return accList;
        }
        public int GetAccountByUser(string p_accName)
        {

            SqlCommand cmdGetAccountByUser = new SqlCommand("select accNo from accountsInfo where accName = @uName", con);
            cmdGetAccountByUser.Parameters.AddWithValue("@uName", p_accName);

            con.Open();
            SqlDataReader readRecord = cmdGetAccountByUser.ExecuteReader(); //store the output in read variable
            BankAccount acc = new BankAccount();
            if (readRecord.Read()) //start reading please
            {
                acc.accNo = (int)readRecord[0];

            }
            else
            {
                throw new Exception("Record Not Found");
            }
            readRecord.Close();
            con.Close();

            return acc.accNo;
        }

        public int GetAccNoByUser(string p_accName, int p_accNo)
        {

            SqlCommand cmdGetAccNoByUser = new SqlCommand("SELECT (accNo) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = @uName and accNo = @accNo group by accNo;", con);
            cmdGetAccNoByUser.Parameters.AddWithValue("@uName", p_accName);
            cmdGetAccNoByUser.Parameters.AddWithValue("@accNo", p_accNo);

            con.Open();
            SqlDataReader readRecord = cmdGetAccNoByUser.ExecuteReader(); //store the output in read variable
            BankAccount acc = new BankAccount();
            if (readRecord.Read()) //start reading please
            {
                acc.accNo = readRecord.GetOrdinal("accNo");

                if (readRecord.IsDBNull(accNo))
                {
                    acc.accNo = 0;
                }
                else
                {
                    acc.accNo = readRecord.GetInt32(accNo);
                }
            }
            readRecord.Close();
            con.Close();
            return acc.accNo;
        }       
           
    }
}



   

