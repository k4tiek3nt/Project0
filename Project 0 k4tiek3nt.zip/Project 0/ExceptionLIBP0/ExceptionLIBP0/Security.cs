﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ExceptionLIBP0
{
    public class Security
    {
        public string userName { get; set; }
        public string userPassword { get; set; }
        public string userStatus { get; set; }
        public int attempts { get; set; }
        public string userRole { get; set; }

        SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=citibankDB;integrated security=true");

        public string Login(string p_uName, string p_pwd, string p_userRole)
        {
            SqlCommand cmdCheckLogin = new SqlCommand("select count(*) from tbl_Login where userName=@uName and password=@pwd and accountRole=@accRole and accountStatus=@Status", con);
            if (p_userRole == "Admin")
            {
                cmdCheckLogin.Parameters.AddWithValue("@accRole", "Admin");
            }
            else
            {
                cmdCheckLogin.Parameters.AddWithValue("@accRole", "User");
            }

            cmdCheckLogin.Parameters.AddWithValue("@uName", p_uName);
            cmdCheckLogin.Parameters.AddWithValue("@pwd", p_pwd);
            cmdCheckLogin.Parameters.AddWithValue("@Status", "Active");

            con.Open();
            int loginResult = (int)cmdCheckLogin.ExecuteScalar();
            con.Close();

            if (p_userRole == "User")
            {
                SqlCommand cmdAttempts = new SqlCommand("select accountStatus,attempts from tbl_Login where userName=@uName", con);

                cmdAttempts.Parameters.AddWithValue("@uName", p_uName);
                con.Open();

                SqlDataReader readUser = cmdAttempts.ExecuteReader();
                if (readUser.Read())
                {
                    string status = readUser[0].ToString();
                    int attempts = (int)readUser[1];
                    readUser.Close();

                    if (status == "Blocked")
                    {
                        return "Account is Blocked, please contact Admin";
                    }
                    if (loginResult == 1 && status == "Active")
                    {
                        return "Login Successful for User " + p_uName;
                    }
                    else
                    {
                        SqlCommand updateAccount;
                        if (attempts == 3)
                        {
                            updateAccount = new SqlCommand("update tbl_Login set accountStatus = 'Blocked' where userName=@uName", con);
                        }
                        else
                        {
                            updateAccount = new SqlCommand("update tbl_Login set attempts=attempts+1 where userName=@uName", con);
                        }
                        updateAccount.Parameters.AddWithValue("@uName", p_uName);
                        updateAccount.ExecuteNonQuery();

                        return "Login Failed for User " + p_uName;
                    }

                }
                con.Close();
                return "Blank";
            }
            else
            {
                if (loginResult == 1)
                {
                    return "Login Successful For Admin";
                }
                else
                {
                    return "Login Failed For Admin";
                }
            }

        }

        public bool CheckUserExist(string p_uName)
        {
            SqlCommand cmdCheckUser = new SqlCommand("select count(*) from tbl_Login where userName = @uName", con);
            cmdCheckUser.Parameters.AddWithValue("@uName", p_uName);

            con.Open();
            int count = (int)cmdCheckUser.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }

        public string AddUserAccount(string p_uName, string p_pwd)
        {
            SqlCommand cmdAddLogin = new SqlCommand("insert into tbl_Login(userName, password) values(@uName, @pwd)", con);
            cmdAddLogin.Parameters.AddWithValue("@uName", p_uName);
            cmdAddLogin.Parameters.AddWithValue("@pwd", p_pwd);
            con.Open();
            int recordsAffected = cmdAddLogin.ExecuteNonQuery(); //this method returns number of records affected in datbase
            con.Close();
            return "Login Added Successfully";
        }

        public List<Security> GetAllLoginAccounts()
        {
            SqlCommand cmdAllLoginAccounts = new SqlCommand("select * from tbl_Login", con);
            con.Open();
            SqlDataReader readSec = cmdAllLoginAccounts.ExecuteReader();


            List<Security> secList = new List<Security>();
            while (readSec.Read())
            {
                secList.Add(new Security()
                {
                    userName = readSec[0].ToString(),
                    userPassword = readSec[1].ToString(),
                    userStatus = readSec[2].ToString(),
                    attempts = (int)readSec[3],
                    userRole = readSec[4].ToString()
                });
            }
            readSec.Close();
            con.Close();
            return secList;
        }

        public List<Security> GetUserLoginInfo(string p_uName_forSearchByUser)
        {
            SqlCommand cmdLoginbyUser = new SqlCommand("select * from tbl_Login where userName=@uName", con);
            cmdLoginbyUser.Parameters.AddWithValue("@uName", p_uName_forSearchByUser);
            con.Open();
            SqlDataReader readSec = cmdLoginbyUser.ExecuteReader();

            List<Security> secList = new List<Security>();
            while (readSec.Read())
            {
                secList.Add(new Security()
                {
                    userName = readSec[0].ToString(),
                    userPassword = readSec[1].ToString(),
                    userStatus = readSec[2].ToString(),
                    attempts = (int)readSec[3],
                    userRole = readSec[4].ToString()
                });
            }
            readSec.Close();
            con.Close();
            return secList;
        }

        public string DisableLogin(string p_uName)
        {
            SqlCommand cmdDisableLogin = new SqlCommand("update tbl_Login set accountStatus=@Status where userName=@uName", con);

            cmdDisableLogin.Parameters.AddWithValue("@uName", p_uName);
            cmdDisableLogin.Parameters.AddWithValue("@Status", "Disabled");


            con.Open();
            int updateResult1 = cmdDisableLogin.ExecuteNonQuery();
            con.Close();

            if (updateResult1 == 1)
            {
                return "Account disabled Successfully";
            }
            return "User Not Found";
        }

        public string ResetLogin(string p_uName)
        {
            SqlCommand cmdResetLogin = new SqlCommand("update tbl_Login set accountStatus=@Status , attempts = @attempts where userName=@uName and accountRole = @urole", con);

            cmdResetLogin.Parameters.AddWithValue("@uName", p_uName);
            cmdResetLogin.Parameters.AddWithValue("@Status", "Active");
            cmdResetLogin.Parameters.AddWithValue("@attempts", 0);
            cmdResetLogin.Parameters.AddWithValue("@urole", "User");

            con.Open();
            int updateResult1 = cmdResetLogin.ExecuteNonQuery();
            con.Close();

            if (updateResult1 == 1)
            {
                return "Account Reset Successfully";
            }
            return "User Not Found";
        }

        public string ResetPassword(string p_uName, string p_pwd)
        {
            SqlCommand cmdResetPwd = new SqlCommand("update tbl_Login set password=@pwd where userName=@uName and accountRole = @urole", con);

            cmdResetPwd.Parameters.AddWithValue("@uName", p_uName);
            cmdResetPwd.Parameters.AddWithValue("@pwd", p_pwd);
            cmdResetPwd.Parameters.AddWithValue("@urole", "User");

            con.Open();
            int updateResult1 = cmdResetPwd.ExecuteNonQuery();
            con.Close();

            if (updateResult1 == 1)
            {
                return "Password Reset Successfully";
            }
            return "User Not Found";
        }

        public bool PasswordCheck(string p_uName, string p_pwd)
        {
            SqlCommand cmdCheckpwd = new SqlCommand("select count(*) from tbl_Login where userName=@uName and password=@pwd and accountRole=@accRole and accountStatus=@Status", con);

            cmdCheckpwd.Parameters.AddWithValue("@accRole", "User");
            cmdCheckpwd.Parameters.AddWithValue("@uName", p_uName);
            cmdCheckpwd.Parameters.AddWithValue("@pwd", p_pwd);
            cmdCheckpwd.Parameters.AddWithValue("@Status", "Active");

            con.Open();
            int pwdResult = (int)cmdCheckpwd.ExecuteScalar();
            con.Close();

            if (pwdResult == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

    }
}
