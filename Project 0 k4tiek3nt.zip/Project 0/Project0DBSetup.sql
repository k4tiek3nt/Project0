create database citibankDB
use citibankDB

--drop table tbl_Login // if need to correct errors in setup

create table tbl_Login
(
	userName varchar(20) not null,
	password varchar(20) not null,
	accountStatus varchar(20) default 'Active',
	attempts int default(0),
	accountRole varchar(20) default 'User',

	constraint pk_userName primary key(userName),
	constraint chk_userName_len check(len(userName) > 2),
	constraint chk_password_len check(len(password) > 4),
	constraint chk_accountStatus_list check (accountStatus in ('Active','Blocked','Disabled')),
	constraint chk_accountRole_list check (accountRole in ('User','Admin'))
)

insert into tbl_Login(userName,password, accountRole) values('Katie','Password1', 'Admin')
insert into tbl_Login(userName,password) values('Rachel','Password2')
insert into tbl_Login(userName,password) values('Monica','Password3')
insert into tbl_Login(userName,password) values('Ross','Password4')
insert into tbl_Login(userName,password) values('Chandler','Password5')
insert into tbl_Login(userName,password) values('Phoebe','Password6')
insert into tbl_Login(userName,password) values('Joey','Password7')
insert into tbl_Login(userName,password) values('Elaine','Password8')
insert into tbl_Login(userName,password) values('George','Password9')
insert into tbl_Login(userName,password) values('Jerry','Password0')

select * from tbl_Login

select count(*) from tbl_Login where userName = 'Chandler' and password = 'Password5' and accountRole = 'User'

--drop table branchInfo
create table branchInfo
(
brNo int identity (1001,1),
brName varchar(20) not null,
brCity varchar(25) not null,
brEmail varchar(40),
brContact varchar(10),

constraint pk_brNo primary key (brNo),
constraint unk_brName unique(brName),
constraint unk_brEmail unique(brEmail),
constraint unk_brContact unique(brContact),
constraint chk_brContact check (len(brContact) = 10)
)

insert into branchInfo (brName, brCity, brEmail, brContact) values ('Head Office', 'Sioux Falls', 'corporate@citibank.com', 6053312626)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('New Castle', 'New Castle', 'newcastle@citibank.com', 3023233101)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Jacksonville', 'Jacksonville', 'jacksonville@citibank.com', 9045510654)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Newark', 'Newark', 'newark@citibank.com', 8006273999)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Clifton', 'Clifton', 'clifton@citibank.com', 9737183119)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('399 Park Avenue', 'New York', 'parkavenue@citibank.com', 6462912727)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Laurel Lakes', 'Laurel', 'laurellakes@citibank.com', 2405471167)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Chula Vista Downtown', 'Chula Vista', 'chulavistadtn@citibank.com', 6196324308)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Citrus Heights', 'Citrus Heights', 'citrusheights@citibank.com', 9164592034)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('River Oaks', 'Calumet City', 'riveroaks@citibank.com', 7087825498)
insert into branchInfo (brName, brCity, brEmail, brContact) values ('Kenwood', 'Chicago', 'kenwood@citibank.com', 7737175980)

--drop table accountsInfo -- if need to fix issues
create table accountsInfo
(
accNo int identity (101,1),
accName varchar(20) not null,
accType varchar(20) not null,
accBalance int not null,
accIsActive varchar(20) default 'Active',
accBranch int,

PRIMARY KEY (accNo,accType),
constraint chk_accName check (len(accName) > 2),
constraint chk_accType check (accType in ('Savings', 'Checking', 'Loan')),
constraint chk_accIsActive_list check (accIsActive in ('Active','Disabled')),
constraint chk_accBalance check (accBalance > 100),
constraint fk_accBranch foreign key(accBranch) references branchInfo
)

insert into accountsInfo (accName, accType, accBalance, accBranch) values('Katie','Loan',150,1001)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Rachel','Savings',150,1002)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Monica','Checking',2000,1003)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Ross','Checking',2000,1004)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Chandler','Savings',150,1005)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Phoebe','Loan',15000,1001)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Joey','Checking',2000,1003)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Elaine','Savings',150,1004)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('George','Loan',150000,1002)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Jerry','Savings',13000,1006)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Katie','Savings',2000,1001)
insert into accountsInfo (accName, accType, accBalance, accBranch) values('Katie','Checking',20000,1001)

--drop table transactionInfo
create table transactionInfo
(
transId int identity,
transDate datetime,
transType varchar(20),
fromAcc int,
fromAccType varchar(20),
toAcc int,
toAccType varchar(20),
transAmt int not null,
transferredBy varchar(20)

constraint pk_transId primary key(transId),
constraint chk_transType check (transType in ('Deposit', 'Withdrawl', 'Transfer')),
constraint fk_fromAcc foreign key (fromAcc, fromAccType) references accountsInfo,
constraint fk_toAcc foreign key (toAcc, toAccType) references accountsInfo
)

select * from tbl_Login --order by accountRole
select * from branchInfo
select * from accountsInfo
select * from transactionInfo

--checking how to write querys
--select accBalance from accountsInfo where accNo = 3 
--update tbl_Login set accountStatus = 'Disabled' where userName = 'Wendy'
--update tbl_Login set accountStatus = 'Blocked', attempts = 3 where userName='Elaine' and accountRole = 'User'

--insert into TransactionInfo values (GETDATE(),'Transfer',102,101,19,'Admin') fixing calendar - was date, needed datetime
--select top 1 accNo from accountsInfo order by accNo desc -- to get last accNo created
--select count(*) from tbl_Login where userName = @uName -- query to check for user name
--select count(*) from tbl_Login where userName = 'Katie' -- testing query

--update AccountsInfo set accBalance = accBalance - @amount where accNo = @fromAccount and @fromAccType - query check for update withdawl
--update AccountsInfo set accBalance = accBalance - 25 where accNo = 109 and accType = 'Loan' -- testing query
--select accType from accountsInfo where accNo=@aNo -- query check for getAccType
--select accType from accountsInfo where accNo=101  -- testing query
--select count(*) from branchInfo where brNo = @brNo -- query check for branch number
--select count(*) from branchInfo where brNo =1007 -- testing query
--select count(*) from accountsInfo where accNo = @aNo -- query check for CheckAccountExist
--select count(*) from accountsInfo where accNo = 101 --- testing query
--select * from tbl_Login where userName=@uName -- query check for User Login info by user
--select * from tbl_Login where userName='Jerry' -- testing query
--select count(*) from accountsInfo where accIsActive = 'Active' and accNo = @aNo -- query check for active account
--select count(*) from accountsInfo where accIsActive = 'Active' and accNo = 112
--update tbl_Login set accountStatus=@Status , attempts = @attempts where userName=@uName and accountRole = @urole -- query check for reset login account
--update tbl_Login set accountStatus = 'Active' , attempts = 0 where userName = 'James' and accountRole = 'User' -- testing query
--SELECT count (accName) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = @uName group by accName;  -- query check for GetAccountsByUser
--SELECT count (accName) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = 'James' group by accName; -- testing query
--SELECT count (accName) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = 'Katie' group by accName; -- testing query
--SELECT count(accNo) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = @uName and accNo = @accNo group by accNo -- query check for GetAccNoByUser
--SELECT count(accNo) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = 'Rachel' and accNo = 114 group by accNo  -- testing query
--SELECT (accNo) FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = 'Mike' and accNo = 116 group by accNo -- testing query - returns blank
--SELECT ISNULL([accNo], -1) AS [accNo] FROM accountsInfo left JOIN tbl_Login ON accountsInfo.accName = tbl_Login.userName where accName = 'Mike' and accNo = 116 group by accNo -- testing query - returns Null 
--SELECT coalesce(a.accNo, 'some text')  AS accNo FROM accountsInfo a left JOIN tbl_Login t ON a.accName = t.userName where accName = 'Mike' and accNo = 116 group by accNo -- testing query - returns Null  --   
--SELECT CASE WHEN a.accNo IS NULL THEN -1 ELSE a.accNo END AS accNo FROM accountsInfo a left JOIN tbl_Login t ON a.accName = t.userName where accName = 'Mike' and accNo = 116 group by accNo  -- testing query - returns Null 
--SELECT ISNULL(a.accNo, '-1') as accNo FROM accountsInfo a Full JOIN tbl_Login t ON a.accName = t.userName where accName = 'Mike' and accNo = 116 group by accNo  -- testing query - returns Null  -- handled in Library to set to 0
--select count(*) from tbl_Login where userName=@uName and password=@pwd and accountRole=@accRole and accountStatus=@Status -- query check for PasswordCheck
--select count(*) from tbl_Login where userName='Mike' and password='Password34' and accountRole='User' and accountStatus= 'Active' -- testing query - passed
--select top 10 transID, transDate, t.transType, t.fromAcc, t.fromAccType, t.toAcc, t.toAccType, t.transAmt, t.transferredBy from transactionInfo t full join accountsInfo a on t.fromAcc = a.accNo or t.toAcc = a.accNo where a.accName = 'Mike' order by transID desc 
--select top 10 transID, transDate, t.transType, t.fromAcc, t.fromAccType, t.toAcc, t.toAccType, t.transAmt, t.transferredBy from transactionInfo t full join accountsInfo a on t.fromAcc = a.accNo or t.toAcc = a.accNo where a.accNo = 115 order by transID desc
