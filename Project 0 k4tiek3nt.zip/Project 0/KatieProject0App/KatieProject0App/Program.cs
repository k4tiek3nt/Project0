﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ExceptionLIBP0;

namespace consoleAppProject0
{
    public class Program
    {
        static void Main(string[] args)
        {
             
            //login with 2 choices
            #region Login Menu
            bool continueLogin = true;
            while (continueLogin)
            {
                try
                {
                    Console.WriteLine("-----CitiBank------");
                    Console.WriteLine("Please Choose Login Option");
                    Console.WriteLine("1. Admin Login");
                    Console.WriteLine("2. Customer Login");
                    #endregion
                    #region Common variables for multiple cases initilised to defaults
                    BankAccount accObj = new BankAccount(); //used for calling methods from library
                    BankAccount newAcc = new BankAccount(); //used for searching,adding and updating the bank record
                    Transactions trObj = new Transactions(); // to call methods from library for transactions
                    Transactions newTr = new Transactions(); //used for searching, adding and updating the transaction records
                    Branch brObj = new Branch(); // to call methods from library for Bank Branchs
                    Branch newBr = new Branch(); //used for searching, adding and updating the branch records
                    ScreenClear rtm = new ScreenClear(); //used to return to main menu
                    ScreenClear dc = new ScreenClear(); //used for default clear
                    bool check = false; //confirms account exists
                    bool check1 = false; //confirms account exists
                    bool checkName = false; //confirms login exists before creating a bank account
                    bool checkBranch = false; //confirms branch exists when creating a bank account
                    bool checkActive = false; //confirms account is active
                    bool checkActive1 = false; //confirms account is active
                    int checkUserAcc = 0; //confirms account owned by user
                    int checkUserAcc1 = 0; //confirms account owned by user
                    int v_balance = 0; //Balance of account
                    int v_balance1 = 0; //Balance of receiving account when owned by User for both sending and receiving
                    int v_toAcc = 0; //Account to receive transfer or deposit
                    int v_fromAcc = 0;
                    #endregion
                    #region Login Variables
                    int LoginOption = Convert.ToInt32(Console.ReadLine());
                    dc.DefaultClear(); // clearing screen after login option chosen
                    string isValidUser; //checks login info is valid
                    Security secObj = new Security(); // to call methods from library for logins for Admin
                    Security secObj2 = new Security(); // to call methods from library for logins for User
                    Security newSec = new Security(); //used for searching,adding and updating the login record
                    #endregion

                    switch (LoginOption)
                    {
                        #region Case 1 - Admin Login
                        case 1:
                            Console.WriteLine("-----CitiBank------");
                            Console.WriteLine("Enter Admin User Name");
                            string v_uName = Console.ReadLine();
                            Console.WriteLine("Enter Password");
                            string v_pwd = Console.ReadLine();
                            string v_userRole = "Admin";
                            isValidUser = secObj.Login(v_uName, v_pwd, v_userRole);
                            if (isValidUser.Contains("Successful"))
                            {
                                while (isValidUser.Contains("Successful"))
                                {

                                    continueLogin = false;
                                    dc.DefaultClear();
                                    try
                                    {
                                        bool continueAdminBanking = true;

                                        while (continueAdminBanking)
                                        {
                                            try
                                            {
                                                #region Admin Menu
                                                Console.WriteLine("Welcome to CitiBank");
                                                Console.WriteLine("Please Choose an Option");
                                                Console.WriteLine("1. Create New Account");
                                                Console.WriteLine("2. View All Accounts");
                                                Console.WriteLine("3. Withdrawl");
                                                Console.WriteLine("4. Deposit");
                                                Console.WriteLine("5. Transfer");
                                                Console.WriteLine("6. Disable Account");
                                                Console.WriteLine("7. Reset Blocked Account");
                                                Console.WriteLine("8. Change Password");
                                                Console.WriteLine("9. Exit");
                                                int choice = Convert.ToInt32(Console.ReadLine());
                                                dc.DefaultClear();
                                                #endregion
                                                #region Switch case for choices in Admin Menu
                                                switch (choice)
                                                {
                                                    #region Choice 1 - Create New Account
                                                    case 1:

                                                        Console.WriteLine("1. Create New Bank Account");
                                                        Console.WriteLine("2. Create New Login Account");
                                                        Console.WriteLine("Please Choose an Option");
                                                        int select = Convert.ToInt32(Console.ReadLine());
                                                        dc.DefaultClear();
                                                        #endregion
                                                        switch (select)
                                                        {
                                                            #region Select 1 - Create New Bank Account
                                                            case 1:
                                                                Console.WriteLine("Enter New Account Name");
                                                                string v_accName = Console.ReadLine();
                                                                if (v_accName.Length < 3)
                                                                {
                                                                    throw new Exception("Please provide valid name with min 3 characters.");
                                                                }
                                                                else
                                                                {
                                                                    checkName = newSec.CheckUserExist(v_accName);
                                                                    if (checkName)
                                                                    {
                                                                        Console.WriteLine("Enter Account Type (Checking, Savings or Loan)");
                                                                        string v_accType = Console.ReadLine();
                                                                        if (v_accType == "Checking" || v_accType == "Savings" || v_accType == "Loan")
                                                                        {
                                                                            Console.WriteLine("Enter Account Balance");
                                                                            int v_aBal = Convert.ToInt32(Console.ReadLine());
                                                                            if (v_aBal > 100)
                                                                            {
                                                                                Console.WriteLine("Enter Account Branch");
                                                                                int v_BrNo = Convert.ToInt32(Console.ReadLine());
                                                                                //check if branch exists
                                                                                checkBranch = brObj.CheckBrachExist(v_BrNo);
                                                                                if (checkBranch)
                                                                                {
                                                                                    string addAccount = newAcc.AddAccount(v_accName, v_accType, v_aBal, v_BrNo);
                                                                                    Console.WriteLine(addAccount);

                                                                                    //print code to display all new account info
                                                                                    Console.WriteLine("You added the following account");
                                                                                    List<BankAccount> cList = accObj.GetLastAccount();
                                                                                    foreach (var item in cList)
                                                                                    {

                                                                                        Console.WriteLine("Bank Account Number : " + item.accNo);
                                                                                        Console.WriteLine("Bank Account Owner Name : " + item.accName);
                                                                                        Console.WriteLine("Bank Account Type : " + item.accType);
                                                                                        Console.WriteLine("Bank Account Balance : " + item.accBalance);
                                                                                        Console.WriteLine("Bank Account is Active : " + item.accIsActive);
                                                                                        Console.WriteLine("Bank Account Branch : " + item.accBranch);
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    Console.WriteLine("Branch does not exist. Please try again.");
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                Console.WriteLine("Opening Balance must be greater than $100. New Account not created.");
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            Console.WriteLine("Account Type must be Checking, Savings or Loan. Please try again.");
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Console.WriteLine("New Account Name does not have a Login. Please create a Login Account First.");
                                                                    }
                                                                    
                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Select 2 - Create New Login Account
                                                            case 2:
                                                                Console.WriteLine("Enter User Name");
                                                                v_uName = Console.ReadLine();
                                                                if (v_uName.Length < 3)
                                                                {
                                                                    throw new Exception("Please provide valid name with min 3 characters.");
                                                                }
                                                                else
                                                                {
                                                                    checkName = newSec.CheckUserExist(v_uName);
                                                                    if (!checkName)
                                                                    {
                                                                        Console.WriteLine("Enter User Password");
                                                                        v_pwd = Console.ReadLine();
                                                                        if (v_pwd.Length > 5)
                                                                        {

                                                                            string result = newSec.AddUserAccount(v_uName, v_pwd);
                                                                            Console.WriteLine(result);
                                                                        }
                                                                        else
                                                                        {
                                                                            Console.WriteLine("Password must be at least 5 characters long and can use letters and numbers.");
                                                                        }
                                                                    }
                                                                    if (checkName)
                                                                    {
                                                                        Console.WriteLine("User Name already in use.");
                                                                        Random ran = new Random();
                                                                        int a = ran.Next(100, 5000);

                                                                        Console.WriteLine("Please choose a different User Name. For example: " + v_uName + "{0}", a);
                                                                    }
                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Default - 1 or 2 not selected
                                                            default:
                                                                Console.WriteLine("Invalid Choice");
                                                                dc.DefaultClear();
                                                                break;
                                                                #endregion
                                                        }
                                                        #region 
                                                        rtm.ReturnToMenu();
                                                        break;
                                                        #endregion
                                                    #region Choice 2 - View All Accounts
                                                    case 2:
                                                        Console.WriteLine("1. View All Bank Accounts");
                                                        Console.WriteLine("2. View Specific Bank Account");
                                                        Console.WriteLine("3. View All Login Accounts");
                                                        Console.WriteLine("4. View Specific Login Account");
                                                        Console.WriteLine("Please Choose an Option");
                                                        int option = Convert.ToInt32(Console.ReadLine());
                                                        dc.DefaultClear();
                                                        #endregion
                                                        switch (option)
                                                        {
                                                            #region Option 1 - View All Bank Accounts 
                                                            case 1:
                                                                List<BankAccount> bList = accObj.GetAllBankAccounts();
                                                                int totalAcc = 0;
                                                                Console.WriteLine("Account Number \t\tOwner Name\t\tType\t\tBalance\t\tStatus\t\tBranch");
                                                                foreach (var item in bList)
                                                                {

                                                                    Console.WriteLine(item.accNo + "\t\t" + item.accName + "\t\t" + item.accType + "\t\t" + item.accBalance + "\t\t" + item.accIsActive + "\t\t" + item.accBranch);
                                                                    //Console.WriteLine(" __________________________________________________________________________________________________________________________");

                                                                    //Console.WriteLine();

                                                                    totalAcc++;
                                                                }
                                                                Console.WriteLine("Total Bank Accounts : " + totalAcc);
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Option 2 - View Specific Bank Account
                                                            case 2:
                                                                Console.WriteLine("Enter Bank Account Number");
                                                                int v_accNo_forSearchById = Convert.ToInt32(Console.ReadLine());

                                                                List<BankAccount> dList = accObj.GetAccountDetails(v_accNo_forSearchById);
                                                                foreach (var item in dList)
                                                                {

                                                                    Console.WriteLine("Bank Account Number : " + item.accNo);
                                                                    Console.WriteLine("Bank Account Owner Name : " + item.accName);
                                                                    Console.WriteLine("Bank Account Type : " + item.accType);
                                                                    Console.WriteLine("Bank Account Balance : " + item.accBalance);
                                                                    Console.WriteLine("Bank Account is Active : " + item.accIsActive);
                                                                    Console.WriteLine("Bank Account Branch : " + item.accBranch);
                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Option 3 - View All Login Accounts
                                                            case 3:
                                                                //list all login accounts
                                                                List<Security> sList = secObj.GetAllLoginAccounts();
                                                                int totalSec = 0;
                                                                Console.WriteLine("User Name\t\tPassword\t\tStatus\t\tAttempts\t\tRole");
                                                                foreach (var item in sList)
                                                                {
                                                                    Console.WriteLine(item.userName + "\t\t" + item.userPassword + "\t\t" + item.userStatus + "\t\t" + item.attempts + "\t\t" + item.userRole);
                                                                    //Console.WriteLine(" __________________________________________________________________________________________________");

                                                                    totalSec++;
                                                                }
                                                                Console.WriteLine("Total Login Accounts : " + totalSec);
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Option 4 - View Specific Login Account 
                                                            case 4:
                                                                Console.WriteLine("Enter User Name");
                                                                string v_uName_forSearchByUser = Console.ReadLine();

                                                                List<Security> uList = secObj.GetUserLoginInfo(v_uName_forSearchByUser);

                                                                foreach (var item in uList)
                                                                {

                                                                    Console.WriteLine("User Login Name : " + item.userName);
                                                                    Console.WriteLine("User Password : " + item.userPassword);
                                                                    Console.WriteLine("User Account Status : " + item.userStatus);
                                                                    Console.WriteLine("User Login Attempts : " + item.attempts);
                                                                    Console.WriteLine("User Account Role : " + item.userRole);
                                                                    //Console.WriteLine(" __________________________________________________________");

                                                                    //Console.WriteLine();

                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Default - 1-4 not selected
                                                            default:
                                                                Console.WriteLine("Invalid Choice");
                                                                dc.DefaultClear();
                                                                break;
                                                                #endregion
                                                        }
                                                        #region 
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 3 - Withdrawl
                                                    case 3:
                                                        //Withdraw - enter account number and amount to withdraw, update balance
                                                        Console.WriteLine("Enter the account number to perform withdrawl");
                                                        v_fromAcc = Convert.ToInt32(Console.ReadLine());

                                                        check = newAcc.CheckAccountExist(v_fromAcc);
                                                        checkActive = newAcc.CheckAccountActive(v_fromAcc);
                                                        if (check && checkActive)
                                                        {
                                                            v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                            Console.WriteLine("Current Balance is: " + v_balance);
                                                            Console.WriteLine("Enter the amount to withdraw");
                                                            int v_withdrawlamt = Convert.ToInt32(Console.ReadLine());
                                                            int withdrawComplete = accObj.Withdrawl(v_withdrawlamt, v_balance);
                                                            Console.WriteLine("Available balance is now : " + withdrawComplete);
                                                            //this now needs to pass to transaction history and update accbalance
                                                            string v_fromAccType = newAcc.GetAccountType(v_fromAcc);
                                                            string v_transType = "Withdrawl";
                                                            v_userRole = "Admin";
                                                            string withdrawlResult = trObj.Withdrawl(v_transType, v_fromAcc, v_fromAccType, v_withdrawlamt, v_userRole);
                                                            Console.WriteLine(withdrawlResult);                                                            
                                                        }
                                                        if (!check)
                                                        {
                                                            Console.WriteLine("Account Number Doesn't Exist");
                                                        }
                                                        if (!checkActive)
                                                        {
                                                            Console.WriteLine("Account is Disabled, Withdrawl not allowed.");
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 4 - Deposit
                                                    case 4:
                                                        //Deposit - enter account number and amount to deposit, update balance
                                                        Console.WriteLine("Enter the account number to perform deposit");
                                                        v_toAcc = Convert.ToInt32(Console.ReadLine());

                                                        check = newAcc.CheckAccountExist(v_toAcc);
                                                        checkActive = newAcc.CheckAccountActive(v_toAcc);
                                                        if (check && checkActive)
                                                        {
                                                            v_balance = newAcc.GetAccountBalance(v_toAcc);
                                                            Console.WriteLine("Current Balance is: " + v_balance);
                                                            Console.WriteLine("Enter the amount to deposit");
                                                            int v_depositAmount = Convert.ToInt32(Console.ReadLine());
                                                            int depositComplete = accObj.Deposit(v_depositAmount, v_balance);
                                                            Console.WriteLine("Available balance is now : " + depositComplete);
                                                            //this now needs to pass to transaction history and update accbalance
                                                            string v_toAccType = newAcc.GetAccountType(v_toAcc);
                                                            string v_transType = "Deposit";
                                                            v_userRole = "Admin";
                                                            string depositResult = trObj.Deposit(v_transType, v_toAcc, v_toAccType, v_depositAmount, v_userRole);
                                                            Console.WriteLine(depositResult);
                                                        }
                                                        if (!check)
                                                        {
                                                            Console.WriteLine("Account Number Doesn't Exist");
                                                        }
                                                        if (!checkActive)
                                                        {
                                                            Console.WriteLine("Account is Disabled, Deposit not allowed.");
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 5 - Transfer
                                                    case 5:
                                                        //transfer - enter account number to transfer from, enter account to 
                                                        //transfer to, enter amount to transfer, update balance to show 
                                                        //account money transfered from
                                                        Console.WriteLine("Enter the account number to transfer funds from");
                                                        v_fromAcc = Convert.ToInt32(Console.ReadLine());
                                                        Console.WriteLine("Enter the account number to deposit transferred funds");
                                                        v_toAcc = Convert.ToInt32(Console.ReadLine());
                                                        check = newAcc.CheckAccountExist(v_fromAcc);
                                                        check1 = newAcc.CheckAccountExist(v_toAcc);
                                                        checkActive = newAcc.CheckAccountActive(v_fromAcc);
                                                        checkActive1 = newAcc.CheckAccountActive(v_toAcc);
                                                        if (check && check1)
                                                        {
                                                            if (checkActive && checkActive1)
                                                            {
                                                                v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                                Console.WriteLine("Current Balance is: " + v_balance);
                                                                Console.WriteLine("Enter the amount to transfer");
                                                                int v_transferAmount = Convert.ToInt32(Console.ReadLine());
                                                                v_balance -= v_transferAmount;
                                                                if (v_balance > 100)
                                                                {
                                                                    Console.WriteLine("Available balance is now : " + v_balance);
                                                                    string v_transType = "Transfer";
                                                                    v_userRole = "Admin";
                                                                    //this now needs to pass to transaction history and update accbalance
                                                                    string v_fromAccType = accObj.GetAccountType(v_fromAcc);
                                                                    string v_toAccType = accObj.GetAccountType(v_toAcc);
                                                                    string transferResult = trObj.Transfer(v_transType, v_fromAcc, v_fromAccType, v_toAcc, v_toAccType, v_transferAmount, v_userRole);
                                                                    Console.WriteLine(transferResult);
                                                                }
                                                                else
                                                                {
                                                                    Console.WriteLine("Account must have greater than $100 to remain open. Transfer rejected.");
                                                                }
                                                            }
                                                            if (!checkActive)
                                                            {
                                                                Console.WriteLine("From Account is Disabled, Transfer not allowed.");
                                                            }
                                                            if (!checkActive1)
                                                            {
                                                                Console.WriteLine("To Account is Disabled, Transfer not allowed.");
                                                            }
                                                        }
                                                        if (!check)
                                                        {
                                                            Console.WriteLine("From Account Number Doesn't Exist,Transfer not allowed.");
                                                        }
                                                        if (!check1)
                                                        {
                                                            Console.WriteLine("To Account Number Doesn't Exist,Transfer not allowed.");
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 6 - Disable Account
                                                    case 6:
                                                        Console.WriteLine("1. DeActivate Bank Account");
                                                        Console.WriteLine("2. Disable Login Account");
                                                        Console.WriteLine("Please Choose an Option");
                                                        int variety = Convert.ToInt32(Console.ReadLine());
                                                        dc.DefaultClear();
                                                        #endregion
                                                        switch (variety)
                                                        {
                                                            #region Variety 1 - DeActivate Bank Account
                                                            case 1:
                                                                Console.WriteLine("Enter Account No to DeActivate");
                                                                accObj.accNo = Convert.ToInt32(Console.ReadLine());

                                                                check = newAcc.CheckAccountExist(accObj.accNo);
                                                                if (check)
                                                                {
                                                                    string deactivateResult = newAcc.DeactivateAccount(accObj.accNo);
                                                                    Console.WriteLine(deactivateResult);
                                                                }
                                                                if (!check)
                                                                {
                                                                    Console.WriteLine("Account Number Doesn't Exist");
                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Variety 2 - Disable Login Account
                                                            case 2:
                                                                Console.WriteLine("Enter Login Name to disable");
                                                                secObj.userName = (Console.ReadLine());
                                                                checkName = newSec.CheckUserExist(secObj.userName);
                                                                if (checkName)
                                                                {
                                                                    string disableResult = newSec.DisableLogin(secObj.userName);
                                                                    Console.WriteLine(disableResult);
                                                                }
                                                                if (!checkName)
                                                                {
                                                                    Console.WriteLine("User name does not exist.");
                                                                    
                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Default - 1 or 2 not chosen, invalid choice.
                                                            default:
                                                                Console.WriteLine("Invalid choice. Please try again.");
                                                                dc.DefaultClear();
                                                                break;
                                                                #endregion
                                                        }
                                                        #region 
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 7 - Reset Blocked Account
                                                    case 7:
                                                        Console.WriteLine("Please Choose an Option");
                                                        Console.WriteLine("1. ReActivate Bank Account");
                                                        Console.WriteLine("2. Reset Blocked Login Account");
                                                        int which = Convert.ToInt32(Console.ReadLine());
                                                        dc.DefaultClear();
                                                        #endregion
                                                        switch (which)
                                                        {
                                                            #region Which 1: ReActivate Bank Account
                                                            case 1:
                                                                Console.WriteLine("Enter Account No to ReActivate");
                                                                accObj.accNo = Convert.ToInt32(Console.ReadLine());

                                                                check = newAcc.CheckAccountExist(accObj.accNo);
                                                                if (check)
                                                                {
                                                                    string ReactivateResult = newAcc.ReactivateAccount(accObj.accNo);
                                                                    Console.WriteLine(ReactivateResult);
                                                                    
                                                                }
                                                                if (!check)
                                                                {
                                                                    Console.WriteLine("Account Number Doesn't Exist");
                                                                   
                                                                }
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Which 2: Reset Blocked Login Account
                                                            case 2:
                                                                Console.WriteLine("Enter Login Name to Reset");
                                                                secObj.userName = (Console.ReadLine());
                                                                string resetResult = newSec.ResetLogin(secObj.userName);
                                                                Console.WriteLine(resetResult);
                                                                rtm.ReturnToMenu();
                                                                break;
                                                            #endregion
                                                            #region Default - 1 - 2 not entered = invalid choice
                                                            default:
                                                                continueAdminBanking = true;
                                                                Console.WriteLine("Invalid Choice");
                                                                dc.DefaultClear();
                                                                break;
                                                                #endregion
                                                        }
                                                        #region 
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 8 - Change Password
                                                    case 8:
                                                        Console.WriteLine("Enter Login Name to change Password");
                                                        secObj.userName = (Console.ReadLine());
                                                        checkName = newSec.CheckUserExist(secObj.userName);
                                                        if (checkName)
                                                        {
                                                            Console.WriteLine("Enter New Password");
                                                            secObj.userPassword = (Console.ReadLine());
                                                            string resetPwdResult = newSec.ResetPassword(secObj.userName, secObj.userPassword);
                                                            Console.WriteLine(resetPwdResult);
                                                        }
                                                        if (!checkName)
                                                        {
                                                            Console.WriteLine("User name does not exist.");
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region Choice 9 - Exit
                                                    case 9:
                                                        Console.WriteLine("Thank you for banking with CitiBank!");
                                                        continueAdminBanking = false;
                                                        isValidUser = "Admin";
                                                        dc.DefaultClear();
                                                        break;
                                                    #endregion
                                                    #region Default - 1 - 9 not entered = invalid choice
                                                    default:
                                                        continueAdminBanking = true;
                                                        Console.WriteLine("Invalid Choice");
                                                        dc.DefaultClear();
                                                        break;
                                                        #endregion
                                                }
                                                #endregion
                                            }
                                            #region continueAdminBanking catch
                                            catch (Exception es)
                                            {
                                                Console.WriteLine(es.Message);
                                                Console.ReadLine();
                                                Console.Clear();
                                            }
                                            #endregion
                                        };
                                    }
                                    #region Catch for isValidUser.Contains("Successful")
                                    catch (Exception es)
                                    {
                                        Console.WriteLine(es.Message);
                                        dc.DefaultClear();
                                    }
                                    #endregion
                                };
                            }
                            #region Else - if Login Fails
                            else
                            {
                                Console.WriteLine(isValidUser);                                
                            }
                            break;
                        #endregion
                        #endregion
                        #region Case 2 - User Login
                        case 2:
                            Console.WriteLine("-----CitiBank------");
                            Console.WriteLine("Enter User Name");
                            string v_userName = Console.ReadLine();
                            Console.WriteLine("Enter Password");
                            string v_userpwd = Console.ReadLine();
                            string v_user = "User";
                            string checkisValidUser = secObj2.Login(v_userName, v_userpwd, v_user);
                            if (checkisValidUser.Contains("Successful"))
                            {
                                while (checkisValidUser.Contains("Successful"))
                                {
                                    continueLogin = false;
                                    dc.DefaultClear();
                                    try
                                    {
                                        bool continueBanking = true;

                                        while (continueBanking)
                                        {
                                            try
                                            {
                                                #region User Menu
                                                Console.WriteLine("Welcome to CitiBank");
                                                Console.WriteLine("Please Choose an Option");
                                                Console.WriteLine("1. Check Balance");
                                                Console.WriteLine("2. Withdrawl");
                                                Console.WriteLine("3. Deposit");
                                                Console.WriteLine("4. Transfer");
                                                Console.WriteLine("5. View Last 10 Transactions");
                                                Console.WriteLine("6. Change Password");
                                                Console.WriteLine("7. Exit");
                                                
                                                int UserMenu = Convert.ToInt32(Console.ReadLine());
                                                dc.DefaultClear();
                                                #endregion
                                                switch (UserMenu)
                                                {
                                                    #region UserMenu 1 - Check Balance
                                                    case 1:
                                                        bool numberOfAccount = newAcc.GetAccountsByUser(v_userName);
                                                        if(numberOfAccount)
                                                        {
                                                           v_balance = newAcc.GetBalanceByUser(v_userName);
                                                           Console.WriteLine("Current Balance is: " + v_balance);
                                                        }
                                                        else
                                                        {
                                                            
                                                            List<BankAccount> allList = accObj.GetAllAccountsByUser(v_userName);
                                                            int totalAcc = 0;
                                                            
                                                            foreach (var item in allList)
                                                            {
                                                                Console.WriteLine("Account Number: " + item.accNo);
                                                                Console.WriteLine("Account Type: " + item.accType);
                                                                Console.WriteLine("Account Balance: " + item.accBalance);
                                                                Console.WriteLine(" _____________________________________________________________________");
                                                                totalAcc++;
                                                            }
                                                            
                                                            Console.WriteLine("Total Bank Accounts: " + totalAcc);
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region UserMenu 2 - Withdrawl
                                                    case 2:
                                                        numberOfAccount = newAcc.GetAccountsByUser(v_userName);
                                                        if (numberOfAccount)
                                                        {
                                                            v_balance = newAcc.GetBalanceByUser(v_userName);
                                                            Console.WriteLine("Current Balance is: " + v_balance);
                                                            v_fromAcc = newAcc.GetAccountByUser(v_userName);
                                                            Console.WriteLine("Enter the amount to Withdraw");
                                                            int v_withdrawlamt = Convert.ToInt32(Console.ReadLine());
                                                            int v_balCheck = v_balance - v_withdrawlamt;
                                                            if (v_balCheck > 100)
                                                            {
                                                                int withdrawComplete = accObj.Withdrawl(v_withdrawlamt, v_balance);
                                                                Console.WriteLine("Available balance is now : " + withdrawComplete);
                                                                //this now needs to pass to transaction history and update accbalance
                                                                string v_fromAccType = newAcc.GetAccountType(v_fromAcc);
                                                                string v_transType = "Withdrawl";
                                                                v_userRole = "User";
                                                                string withdrawlResult = trObj.Withdrawl(v_transType, v_fromAcc, v_fromAccType, v_withdrawlamt, v_userRole);
                                                                Console.WriteLine(withdrawlResult);
                                                            }
                                                            else
                                                            {
                                                                Console.WriteLine("Account must have greater than $100 to remain open. Withdrawl rejected.");
                                                            }

                                                        }
                                                        else
                                                        {
                                                            List<BankAccount> accbyUserList = accObj.GetAllAccountsByUser(v_userName);
                                                            
                                                            foreach (var item in accbyUserList)
                                                            {
                                                                Console.WriteLine("Account Number: " + item.accNo);
                                                                Console.WriteLine("Account Type: " + item.accType);
                                                                Console.WriteLine("Account Balance: " + item.accBalance);
                                                                Console.WriteLine(" _____________________________________________________________________");
                                                               
                                                            }

                                                            Console.WriteLine("Enter the account number to perform withdrawl");
                                                            v_fromAcc = Convert.ToInt32(Console.ReadLine());

                                                            check = newAcc.CheckAccountExist(v_fromAcc);
                                                            checkActive = newAcc.CheckAccountActive(v_fromAcc);
                                                            checkUserAcc = newAcc.GetAccNoByUser(v_userName, v_fromAcc);
                                                            
                                                            if (check && checkActive)
                                                            {
                                                                if (checkUserAcc == v_fromAcc)
                                                                {
                                                                    v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                                    Console.WriteLine("Current Balance is: " + v_balance);
                                                                    Console.WriteLine("Enter the amount to withdraw");
                                                                    int v_withdrawlamt = Convert.ToInt32(Console.ReadLine());
                                                                    int withdrawComplete = accObj.Withdrawl(v_withdrawlamt, v_balance);
                                                                    Console.WriteLine("Available balance is now : " + withdrawComplete);
                                                                    //this now needs to pass to transaction history and update accbalance
                                                                    string v_fromAccType = newAcc.GetAccountType(v_fromAcc);
                                                                    string v_transType = "Withdrawl";
                                                                    v_userRole = "User";
                                                                    string withdrawlResult = trObj.Withdrawl(v_transType, v_fromAcc, v_fromAccType, v_withdrawlamt, v_userRole);
                                                                    Console.WriteLine(withdrawlResult);
                                                                }
                                                                if (checkUserAcc == 0)
                                                                {
                                                                    Console.WriteLine("You entered an account that does not belong to you. Withdrawl not allowed.");
                                                                }
                                                            }
                                                            if (!check)
                                                            {
                                                                Console.WriteLine("Account Number Doesn't Exist");
                                                            }
                                                            if (!checkActive)
                                                            {
                                                                Console.WriteLine("Account is Disabled, Withdrawl not allowed.");
                                                            }
                                                            
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region UserMenu 3 - Deposit
                                                    case 3:
                                                        numberOfAccount = newAcc.GetAccountsByUser(v_userName);
                                                        if (numberOfAccount)
                                                        {
                                                            v_balance = newAcc.GetBalanceByUser(v_userName);
                                                            Console.WriteLine("Current Balance is: " + v_balance);
                                                            v_toAcc = newAcc.GetAccountByUser(v_userName);
                                                           
                                                            Console.WriteLine("Enter the amount to deposit");
                                                            int v_depositAmount = Convert.ToInt32(Console.ReadLine());
                                                            int depositComplete = accObj.Deposit(v_depositAmount, v_balance);
                                                            Console.WriteLine("Available balance is now : " + depositComplete);
                                                            //this now needs to pass to transaction history and update accbalance
                                                            string v_toAccType = newAcc.GetAccountType(v_toAcc);
                                                            string v_transType = "Deposit";
                                                            v_userRole = "User";
                                                            string depositResult = trObj.Deposit(v_transType, v_toAcc, v_toAccType, v_depositAmount, v_userRole);
                                                            Console.WriteLine(depositResult);


                                                        }
                                                        else
                                                        {
                                                            List<BankAccount> accbyUserList = accObj.GetAllAccountsByUser(v_userName);

                                                            foreach (var item in accbyUserList)
                                                            {
                                                                Console.WriteLine("Account Number: " + item.accNo);
                                                                Console.WriteLine("Account Type: " + item.accType);
                                                                Console.WriteLine("Account Balance: " + item.accBalance);
                                                                Console.WriteLine(" _____________________________________________________________________");

                                                            }

                                                            Console.WriteLine("Enter the account number to perform Deposit");
                                                            v_toAcc = Convert.ToInt32(Console.ReadLine());

                                                            check = newAcc.CheckAccountExist(v_toAcc);
                                                            checkActive = newAcc.CheckAccountActive(v_toAcc);
                                                            checkUserAcc = newAcc.GetAccNoByUser(v_userName, v_toAcc);
                            
                                                            if (check && checkActive && checkUserAcc == v_toAcc)
                                                            {
                                                                Console.WriteLine("Enter the amount to deposit");
                                                                int v_depositAmount = Convert.ToInt32(Console.ReadLine());

                                                                v_balance = newAcc.GetAccountBalance(v_toAcc);
                                                                int depositComplete = accObj.Deposit(v_depositAmount, v_balance);
                                                                Console.WriteLine("Available balance is now : " + depositComplete);
                                                                //this now needs to pass to transaction history and update accbalance
                                                                string v_toAccType = newAcc.GetAccountType(v_toAcc);
                                                                string v_transType = "Deposit";
                                                                v_userRole = "User";
                                                                string depositResult = trObj.Deposit(v_transType, v_toAcc, v_toAccType, v_depositAmount, v_userRole);
                                                                Console.WriteLine(depositResult);
                                                            }
                                                            if (!check)
                                                            {
                                                                Console.WriteLine("Account Number Doesn't Exist");
                                                            }
                                                            if (!checkActive)
                                                            {
                                                                Console.WriteLine("Account is Disabled, Deposit not allowed.");
                                                            }
                                                            if (checkUserAcc == 0)
                                                            {
                                                                //because account doesn't belong to user only allowing deposit
                                                                //not displaying balance results to user.
                                                                Console.WriteLine("Enter the amount to deposit");
                                                                int v_depositAmount = Convert.ToInt32(Console.ReadLine());
                                                                v_balance = newAcc.GetAccountBalance(v_toAcc);
                                                                int depositComplete = accObj.Deposit(v_depositAmount, v_balance);
                                                                //this now needs to pass to transaction history and update accbalance
                                                                string v_toAccType = newAcc.GetAccountType(v_toAcc);
                                                                string v_transType = "Deposit";
                                                                v_userRole = "User";
                                                                string depositResult = trObj.Deposit(v_transType, v_toAcc, v_toAccType, v_depositAmount, v_userRole);
                                                                Console.WriteLine(depositResult);
                                                            }
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region UserMenu 4 - Transfer
                                                    case 4:
                                                        //transfer - enter account number to transfer from, enter account to 
                                                        //transfer to, enter amount to transfer, update balance to show 
                                                        //account money transfered from
                                                        numberOfAccount = newAcc.GetAccountsByUser(v_userName);
                                                        if (numberOfAccount)
                                                        {
                                                            v_fromAcc = newAcc.GetAccountByUser(v_userName);
                                                            v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                            Console.WriteLine("Enter the account number to deposit transferred funds");
                                                            v_toAcc = Convert.ToInt32(Console.ReadLine());
                                                            check1 = newAcc.CheckAccountExist(v_toAcc);
                                                            checkActive = newAcc.CheckAccountActive(v_fromAcc); 
                                                            checkActive1 = newAcc.CheckAccountActive(v_toAcc);
                                                            
                                                            if (check1)
                                                            {
                                                                if (checkActive && checkActive1)
                                                                {
                                                                    Console.WriteLine("Current Balance is: " + v_balance);
                                                                    Console.WriteLine("Enter the amount to Transfer");
                                                                    int v_transferAmount = Convert.ToInt32(Console.ReadLine());
                                                                    v_balance -= v_transferAmount;
                                                                    if (v_balance > 100)
                                                                    {
                                                                        string v_transType = "Transfer";
                                                                        v_userRole = "User";
                                                                        //this now needs to pass to transaction history and update accbalance
                                                                        string v_fromAccType = accObj.GetAccountType(v_fromAcc);
                                                                        string v_toAccType = accObj.GetAccountType(v_toAcc);
                                                                        string transferResult = trObj.Transfer(v_transType, v_fromAcc, v_fromAccType, v_toAcc, v_toAccType, v_transferAmount, v_userRole);
                                                                        Console.WriteLine(transferResult);
                                                                        checkUserAcc1 = newAcc.GetAccNoByUser(v_userName, v_toAcc);

                                                                        if (checkUserAcc1 == v_toAcc)
                                                                        {
                                                                            v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                                            Console.WriteLine("Current Balance for account transferring funds: " + v_balance);
                                                                            v_balance1 = newAcc.GetAccountBalance(v_toAcc);
                                                                            Console.WriteLine("Current Balance for account receiving funds: " + v_balance1);
                                                                        }
                                                                        if (checkUserAcc1 == 0)
                                                                        {
                                                                            v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                                            Console.WriteLine("Current Balance for account transferring funds: " + v_balance);
                                                                        }                                                                        
                                                                    }
                                                                    else
                                                                    {
                                                                        Console.WriteLine("Account must have greater than $100 to remain open. Transfer rejected.");
                                                                    }
                                                                }
                                                                if (!checkActive)
                                                                {
                                                                    Console.WriteLine("From Account is Disabled, Transfer not allowed.");
                                                                }
                                                                if (!checkActive1)
                                                                {
                                                                    Console.WriteLine("To Account is Disabled, Transfer not allowed.");
                                                                }
                                                            }
                                                            if (!check1)
                                                            {
                                                                Console.WriteLine("To Account Number Doesn't Exist,Transfer not allowed.");
                                                            }                                                            
                                                        }
                                                        else
                                                        {
                                                            List<BankAccount> accbyUserList = accObj.GetAllAccountsByUser(v_userName);

                                                            foreach (var item in accbyUserList)
                                                            {
                                                                Console.WriteLine("Account Number: " + item.accNo);
                                                                Console.WriteLine("Account Type: " + item.accType);
                                                                Console.WriteLine("Account Balance: " + item.accBalance);
                                                                Console.WriteLine(" _____________________________________________________________________");

                                                            }
                                                            Console.WriteLine("Enter the account number to perform Transfer");
                                                            v_fromAcc = Convert.ToInt32(Console.ReadLine());
                                                            checkUserAcc = newAcc.GetAccNoByUser(v_userName, v_fromAcc);
                                                            if (checkUserAcc == 0)
                                                            {
                                                                Console.WriteLine("Transfer not allowed from an account that does not belong to user.");
                                                            }
                                                            else
                                                            {
                                                                check = newAcc.CheckAccountExist(v_fromAcc);
                                                                Console.WriteLine("Enter the account number to deposit transferred funds");
                                                                v_toAcc = Convert.ToInt32(Console.ReadLine());
                                                                checkUserAcc1 = newAcc.GetAccNoByUser(v_userName, v_toAcc);
                                                                check1 = newAcc.CheckAccountExist(v_toAcc);
                                                            }
                                                            if (check && check1)
                                                            {
                                                                checkActive = newAcc.CheckAccountActive(v_fromAcc);
                                                                checkActive1 = newAcc.CheckAccountActive(v_toAcc);

                                                                if (checkActive && checkActive1)
                                                                {
                                                                    Console.WriteLine("Enter the amount to Transfer");
                                                                    int v_transferAmount = Convert.ToInt32(Console.ReadLine());
                                                                    v_balance = accObj.GetAccountBalance(v_fromAcc);
                                                                    v_balance -= v_transferAmount;
                                                                    if (v_balance > 100)
                                                                    {
                                                                       
                                                                            string v_transType = "Transfer";
                                                                            v_userRole = "User";
                                                                            //this now needs to pass to transaction history and update accbalance
                                                                            string v_fromAccType = accObj.GetAccountType(v_fromAcc);
                                                                            string v_toAccType = accObj.GetAccountType(v_toAcc);
                                                                            string transferResult = trObj.Transfer(v_transType, v_fromAcc, v_fromAccType, v_toAcc, v_toAccType, v_transferAmount, v_userRole);
                                                                            Console.WriteLine(transferResult);
                                                                        if (checkUserAcc == v_fromAcc && checkUserAcc1 == v_toAcc)
                                                                        {
                                                                            v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                                            Console.WriteLine("Current Balance for account transferring funds: " + v_balance);
                                                                            v_balance1 = newAcc.GetAccountBalance(v_toAcc);
                                                                            Console.WriteLine("Current Balance for account receiving funds: " + v_balance1);
                                                                        }
                                                                        if (checkUserAcc == v_fromAcc && checkUserAcc1 == 0)
                                                                        {
                                                                            v_balance = newAcc.GetAccountBalance(v_fromAcc);
                                                                            Console.WriteLine("Current Balance for account transferring funds: " + v_balance);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Console.WriteLine("Account must have greater than $100 to remain open. Transfer rejected.");
                                                                    }

                                                                }
                                                                if (!checkActive)
                                                                {
                                                                    Console.WriteLine("From Account is Disabled, Transfer not allowed.");
                                                                }
                                                                if (!checkActive1)
                                                                {
                                                                    Console.WriteLine("To Account is Disabled, Transfer not allowed.");
                                                                }
                                                            }
                                                            if (!check)
                                                            {
                                                                Console.WriteLine("From Account Number Doesn't Exist,Transfer not allowed.");
                                                            }
                                                            if (!check1)
                                                            {
                                                                Console.WriteLine("To Account Number Doesn't Exist,Transfer not allowed.");
                                                            }
                                                            
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region UserMenu 5 - View Last 10 Transactions
                                                    case 5:
                                                        numberOfAccount = newAcc.GetAccountsByUser(v_userName);
                                                        if (numberOfAccount)
                                                        {
                                                            List<Transactions> accbyUserTransList = trObj.GetLast10Trans(v_userName);
                                                            Console.WriteLine("Trans Id      Date      Trans Type  From Acc#  From Acc Type  To Acc# To Acc Type  Amount  Requester");
                                                            foreach (var item in accbyUserTransList)
                                                            {
                                                                Console.WriteLine(item.transId + "  " + item.transDate + "   " + item.transType + "  " + item.fromAcc + "  " + item.fromAccType + "  " + item.toAcc + "  " + item.toAccType + "  " + item.transAmt + "  " + item.transferredBy);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            List<BankAccount> accbyUserList = accObj.GetAllAccountsByUser(v_userName);

                                                            foreach (var item in accbyUserList)
                                                            {
                                                                Console.WriteLine("Account Number: " + item.accNo);
                                                                Console.WriteLine("Account Type: " + item.accType);
                                                            }

                                                            Console.WriteLine("Enter the account number view last 10 transactions");
                                                            int v_transAcc = Convert.ToInt32(Console.ReadLine());
                                                            check = newAcc.CheckAccountExist(v_transAcc);
                                                            checkActive = newAcc.CheckAccountActive(v_transAcc);
                                                            checkUserAcc = newAcc.GetAccNoByUser(v_userName, v_transAcc);

                                                            if (check)
                                                            {
                                                                if (checkActive)
                                                                {
                                                                    if (checkUserAcc == v_transAcc)
                                                                    {
                                                                        //print trans
                                                                        List<Transactions> accTransList = trObj.GetLast10TransbyAcc(v_transAcc);
                                                                        Console.WriteLine("Trans Id      Date      Trans Type  From Acc#  From Acc Type  To Acc# To Acc Type  Amount  Requester");
                                                                        foreach (var item in accTransList)
                                                                        {
                                                                            Console.WriteLine(item.transId + "  " + item.transDate + "   " + item.transType + "  " + item.fromAcc + "  " + item.fromAccType + "  " + item.toAcc + "  " + item.toAccType + "  " + item.transAmt + "  " + item.transferredBy);
                                                                        }                                                                        
                                                                    }
                                                                    if (checkUserAcc == 0)
                                                                    {
                                                                        Console.WriteLine("Account Entered Does Not Belong to You. Cannot Display Transactions.");
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    Console.WriteLine("Account Entered is Not Active. Please Try Again.");
                                                                }
                                                            }
                                                            else
                                                            {
                                                                Console.WriteLine("Account Entered Does Not Exist. Please Try Again.");
                                                            }
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region UserMenu 6 - Change Password
                                                    case 6:
                                                        Console.WriteLine("Enter Current Password");
                                                        string v_userpwdCheck = Console.ReadLine();
                                                        
                                                        if (v_userpwdCheck == v_userpwd)
                                                        {

                                                            Console.WriteLine("Enter New Password");
                                                            string v_newPassword = Console.ReadLine();
                                                            Console.WriteLine("Re-Enter New Password");
                                                            string v_newPwdCheck = Console.ReadLine();

                                                            if (v_newPassword == v_newPwdCheck)
                                                            {
                                                                string resetUserPwdResult = newSec.ResetPassword(v_userName, v_newPassword);
                                                                Console.WriteLine(resetUserPwdResult);
                                                            }
                                                            else
                                                            {
                                                                Console.WriteLine("New Password Does Not Match Re-Entered New Password, Change Password Rejected.");
                                                            }
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("Wrong Password Entered, Change Password Rejected.");
                                                        }
                                                        rtm.ReturnToMenu();
                                                        break;
                                                    #endregion
                                                    #region UserMenu 7 - Exit
                                                    case 7:
                                                    Console.WriteLine("Thank you for banking with CitiBank!");
                                                    continueBanking = false;
                                                    isValidUser = "User";
                                                    checkisValidUser = "User";
                                                        dc.DefaultClear();
                                                        break;
                                                #endregion
                                                    #region Default - 1 - 7 not entered = invalid choice
                                                default:
                                                        continueBanking = true;
                                                        Console.WriteLine("Invalid Choice");
                                                        dc.DefaultClear();
                                                        break;
                                                #endregion
                                                }
                                                
                                            }
                                            #region continueBanking catch
                                            catch (Exception es) 
                                            {
                                                Console.WriteLine(es.Message);
                                                dc.DefaultClear();
                                            }
                                            #endregion
                                        }
                                    }
                                    #region continueLogin catch
                                    catch (Exception es)
                                    {
                                        Console.WriteLine(es.Message);
                                        Console.ReadLine();
                                        Console.Clear();
                                    }
                                    #endregion
                                }
                            }
                            #region If Login Fails
                            else
                            {
                                Console.WriteLine(checkisValidUser);
                                
                            }
                            rtm.ReturnToMenu();
                            break;
                            #endregion
                        #endregion
                        #region Default - 1 or 2 not selected
                        default:
                            Console.WriteLine("Invalid Choice");
                            continueLogin = true;
                            dc.DefaultClear();
                            break;
                            #endregion
                    }
                }
                #region continueLogin catch
                catch (Exception es)
                {
                    Console.WriteLine(es.Message);
                    Thread.Sleep(2000);
                    Console.Clear();
                }
                #endregion
            }
        }
    }
}